"""
KotobaTranscriber - 日本語音声文字起こしアプリケーション
kotoba-whisper v2.2を使用
"""

__version__ = "0.1.0"
__author__ = "KotobaTranscriber Development Team"
